Login website with facebook by php and javascript
